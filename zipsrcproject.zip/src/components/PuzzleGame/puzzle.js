// src/App.js
import React from 'react';
// import './Puzzle.css';
import Board from './board';

function App() {
  return (
    <div className="App">
      <h1>15 Puzzle Game</h1>
      <Board />
    </div>
  );
}

export default App;
